package com.example.tvlauncher

/*
 * build.gradle.kts (app) dependencies:
 *
 *   implementation(platform("androidx.compose:compose-bom:2024.10.01"))
 *   implementation("androidx.compose.ui:ui")
 *   implementation("androidx.compose.foundation:foundation")
 *   implementation("androidx.compose.material:material-icons-extended")
 *   implementation("androidx.tv:tv-material:1.0.0")
 *   implementation("androidx.activity:activity-compose:1.9.3")
 *   implementation("androidx.core:core-ktx:1.13.1")
 *
 * minSdk = 26, targetSdk = 34 (Android 14)
 */

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import android.os.Bundle
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.tv.material3.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val FocusYellow = Color(0xFFFFD600)

// ---------------------------------------------------------------- Activity

@OptIn(ExperimentalTvMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                HomeScreen()
            }
        }
    }
}

// ---------------------------------------------------------------- Data

data class AppItem(val label: String, val packageName: String, val banner: ImageBitmap)

data class ContentItem(val title: String, val color: Color, val live: Boolean = false)

/** Televizorda quraşdırılmış (Leanback) tətbiqləri tapır. */
fun loadInstalledApps(context: Context): List<AppItem> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != context.packageName }
        .map {
            val drawable = it.activityInfo.loadBanner(pm) ?: it.loadIcon(pm)
            AppItem(
                label = it.loadLabel(pm).toString(),
                packageName = it.activityInfo.packageName,
                banner = drawable.toBitmap(320, 180).asImageBitmap()
            )
        }
        .sortedBy { it.label }
}

fun launchApp(context: Context, packageName: String) {
    context.packageManager.getLeanbackLaunchIntentForPackage(packageName)?.let {
        context.startActivity(it)
    }
}

// ---------------------------------------------------------------- Screen

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun HomeScreen() {
    val context = LocalContext.current
    val apps = remember { loadInstalledApps(context) }

    // Nümunə məzmun (əsl layihədə öz API-nizdən və ya Watch Next-dən gələcək)
    val recent = remember { listOf(ContentItem("Canlı yayım", Color(0xFF5B2A2A), live = true)) }
    val recommended = remember {
        listOf(
            ContentItem("Film 1", Color(0xFFB8741A)),
            ContentItem("Serial 2", Color(0xFF2B3A55)),
            ContentItem("Film 3", Color(0xFF8E2B2B)),
            ContentItem("Serial 4", Color(0xFF3B4A2B)),
            ContentItem("Film 5", Color(0xFF4A2B55)),
        )
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF05070A))) {
        Row(Modifier.fillMaxSize()) {
            SideRail()
            Column(Modifier.weight(1f).fillMaxHeight()) {
                HeroBanner(Modifier.fillMaxWidth().weight(1.1f))
                Spacer(Modifier.height(12.dp))
                ContentRows(recent, recommended, Modifier.padding(start = 24.dp))
                Spacer(Modifier.height(16.dp))
                AppsRow(apps, Modifier.padding(start = 24.dp))
                Spacer(Modifier.height(12.dp))
            }
        }
        StatusPill(Modifier.align(Alignment.TopEnd).padding(24.dp))
    }
}

// ---------------------------------------------------------------- Parts

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun SideRail() {
    val items: List<ImageVector> = listOf(
        Icons.Outlined.Person,
        Icons.Outlined.Search,
        Icons.Outlined.ChildCare,
        Icons.Outlined.SportsEsports,
        Icons.Outlined.Notifications,
        Icons.Outlined.Settings,
    )
    Column(
        Modifier.fillMaxHeight().width(72.dp).padding(vertical = 24.dp),
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        items.forEach { icon ->
            IconButton(
                onClick = { /* TODO: naviqasiya */ },
                colors = IconButtonDefaults.colors(
                    containerColor = Color.Transparent,
                    contentColor = Color.White,
                    focusedContainerColor = Color.White,
                    focusedContentColor = Color.Black
                )
            ) {
                Icon(icon, contentDescription = null)
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun HeroBanner(modifier: Modifier = Modifier) {
    Box(
        modifier.background(
            Brush.horizontalGradient(listOf(Color(0xFF05070A), Color(0xFF1C2A2A), Color(0xFF3D5A52)))
        )
    ) {
        Column(Modifier.align(Alignment.CenterStart).padding(start = 24.dp)) {
            Text("ORIGINAL", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(
                "THE LAST OF US",
                color = Color.White,
                fontSize = 52.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { /* TODO: ətraflı */ },
                shape = ButtonDefaults.shape(RoundedCornerShape(24.dp)),
                border = ButtonDefaults.border(
                    focusedBorder = Border(BorderStroke(3.dp, FocusYellow))
                )
            ) {
                Text("Learn More")
            }
        }
        // Real layihədə: arxa fon şəkli və ya video üçün Coil / ExoPlayer istifadə edin
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun ContentRows(
    recent: List<ContentItem>,
    recommended: List<ContentItem>,
    modifier: Modifier = Modifier
) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
        Column {
            Text("Recent", color = Color.White, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            recent.forEach { ContentCard(it, Modifier.size(width = 250.dp, height = 140.dp)) }
        }
        Column(Modifier.weight(1f)) {
            Text("Recommended for you", color = Color.White, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                items(recommended) {
                    ContentCard(it, Modifier.size(width = 240.dp, height = 140.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun ContentCard(item: ContentItem, modifier: Modifier = Modifier) {
    Card(
        onClick = { /* TODO: məzmunu aç */ },
        modifier = modifier,
        shape = CardDefaults.shape(RoundedCornerShape(6.dp)),
        scale = CardDefaults.scale(focusedScale = 1.06f),
        border = CardDefaults.border(
            focusedBorder = Border(BorderStroke(3.dp, FocusYellow))
        )
    ) {
        Box(Modifier.fillMaxSize().background(item.color)) {
            if (item.live) {
                Text(
                    "LIVE",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .padding(6.dp)
                        .background(Color.Red, RoundedCornerShape(3.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            Text(
                item.title,
                color = Color.White,
                modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp)
            )
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun AppsRow(apps: List<AppItem>, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        // Giriş mənbəyi (HDMI və s.) düyməsi
        IconButton(
            onClick = { context.startActivity(Intent("android.settings.INPUT_METHOD_SETTINGS")) },
            modifier = Modifier.size(64.dp),
            shape = IconButtonDefaults.shape(CircleShape),
            colors = IconButtonDefaults.colors(
                containerColor = Color(0xFF2A2D31),
                contentColor = Color.White,
                focusedContainerColor = Color.White,
                focusedContentColor = Color.Black
            )
        ) { Icon(Icons.Outlined.Input, contentDescription = "Input") }

        Spacer(Modifier.width(20.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(apps, key = { it.packageName }) { app ->
                Card(
                    onClick = { launchApp(context, app.packageName) },
                    modifier = Modifier.size(width = 100.dp, height = 64.dp),
                    shape = CardDefaults.shape(RoundedCornerShape(6.dp)),
                    scale = CardDefaults.scale(focusedScale = 1.12f),
                    border = CardDefaults.border(
                        focusedBorder = Border(BorderStroke(3.dp, FocusYellow))
                    )
                ) {
                    Image(
                        bitmap = app.banner,
                        contentDescription = app.label,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun StatusPill(modifier: Modifier = Modifier) {
    var time by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val fmt = SimpleDateFormat("hh:mm a", Locale.getDefault())
        while (true) {
            time = fmt.format(Date())
            delay(15_000)
        }
    }
    Row(
        modifier
            .background(Color(0x33FFFFFF), RoundedCornerShape(20.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.Wifi, contentDescription = null,
            tint = Color.White, modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(time, color = Color.White, fontSize = 14.sp)
    }
}

/*
 * AndroidManifest.xml
 * -------------------
 * <uses-feature android:name="android.software.leanback" android:required="true" />
 * <uses-feature android:name="android.hardware.touchscreen" android:required="false" />
 *
 * <!-- Android 11+ üçün: quraşdırılmış tətbiqləri görmək -->
 * <queries>
 *     <intent>
 *         <action android:name="android.intent.action.MAIN" />
 *         <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
 *     </intent>
 * </queries>
 *
 * <application android:banner="@drawable/banner" ...>
 *     <activity
 *         android:name=".MainActivity"
 *         android:exported="true"
 *         android:launchMode="singleTask"
 *         android:theme="@style/Theme.AppCompat.NoActionBar">
 *         <intent-filter>
 *             <action android:name="android.intent.action.MAIN" />
 *             <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
 *         </intent-filter>
 *         <intent-filter>
 *             <action android:name="android.intent.action.MAIN" />
 *             <category android:name="android.intent.category.HOME" />
 *             <category android:name="android.intent.category.DEFAULT" />
 *         </intent-filter>
 *     </activity>
 * </application>
 */
